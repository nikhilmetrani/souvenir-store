/**
 * 
 */
package sg.edu.nus.iss.se23pt2.pos.exception;

/**
 * @author Nikhil Metrani
 *
 */
public class InvalidVendorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 */
	public InvalidVendorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
