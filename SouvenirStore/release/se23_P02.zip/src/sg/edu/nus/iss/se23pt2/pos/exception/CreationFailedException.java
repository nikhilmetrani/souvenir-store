package sg.edu.nus.iss.se23pt2.pos.exception;

public class CreationFailedException extends Exception{

    public CreationFailedException(String msg){
        super(msg);
    }
}
