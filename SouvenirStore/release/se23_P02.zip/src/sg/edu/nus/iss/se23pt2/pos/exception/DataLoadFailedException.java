package sg.edu.nus.iss.se23pt2.pos.exception;

public class DataLoadFailedException extends Exception{

    public DataLoadFailedException(String msg){
        super(msg);
    }
}
