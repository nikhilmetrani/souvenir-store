package sg.edu.nus.iss.se23pt2.pos.exception;

public class UpdateFailedException extends Exception{

    public UpdateFailedException(String msg){
        super(msg);
    }
}
