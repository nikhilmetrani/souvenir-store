package sg.edu.nus.iss.se23pt2.pos.exception;

public class RemoveFailedException extends Exception{

    public RemoveFailedException(String msg){
        super(msg);
    }
}
